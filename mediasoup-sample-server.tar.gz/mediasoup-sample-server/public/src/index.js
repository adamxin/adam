module.exports = require('./peer');
