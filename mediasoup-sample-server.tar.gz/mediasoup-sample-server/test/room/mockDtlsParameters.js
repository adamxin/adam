module.exports = Object.freeze({
  fingerprints: [
    {
      algorithm: 'sha-256',
      value: '82:5A:68:3D:36:C3:0A:DE:AF:E7:32:43:D2:88:83:57:AC:2D:65:E5:80:C4:B6:FB:AF:1A:A0:21:9F:6D:0C:AD'
    }
  ]
});
